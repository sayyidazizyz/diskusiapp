<?php
$db = mysqli_connect("localhost","root","","web-grup");
$url = "http://localhost/web-grup/";
?>
