<?php
header("location:../error/");
?>