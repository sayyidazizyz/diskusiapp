<?php
header("location:../../../error");
?>